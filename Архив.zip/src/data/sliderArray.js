export const sliderArray = [
    {
        id: 1,
        text: "Скидка на ковровое покрытие",
        img: "./img/slide/1.jpg",
        text_btn: "Заказать звонок"
    },
    {
        id: 2,
        text: "Заголовок",
        img: "./img/slide/2.jpg",
        text_btn: "Кнопка"
    }
]