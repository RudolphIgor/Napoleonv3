export const menuItems = [
    {
        id: 1,
        title: "Главная",
        route: 'section1'
    },
    {
        id: 2,
        title: "Каталог",
        route: 'section2'
    },
    {
        id: 3,
        title: "О нас",
        route: 'section3'
    },
    {
        id: 4,
        title: "Акции",
        route: 'section4'
    },
    {
        id: 5,
        title: "Отзывы",
        route: 'section5'
    }
]