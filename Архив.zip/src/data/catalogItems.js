export const catalogItems = [
    {
        id: 1,
        title: 'керамогранит',
        image: "./img/catalog/keramogranit.jpg"
    },
    {
        id: 2,
        title: 'плитка пвх',
        image: "./img/catalog/plitkaPvh.jpg"
    },
    {
        id: 3,
        title: 'плинтуса',
        image: "./img/catalog/plintus.jpg"
    },
    {
        id: 4,
        title: 'рейка',
        image: "./img/catalog/reika.jpg"
    },
    {
        id: 5,
        title: 'ковровые покрытия',
        image: "./img/catalog/kover.jpg"
    },
    {
        id: 6,
        title: 'линолеум',
        image: "./img/catalog/linoleum.jpg"
    },
    {
        id: 7,
        title: 'ламинат',
        image: "./img/catalog/laminat.jpg"
    }
]